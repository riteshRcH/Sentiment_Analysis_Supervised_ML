using System;

namespace CSharpCrawler
{
    class Program
    {
        static void Main(string[] args)
        {
            Crawler.CrawlSite();

            Console.ReadLine();
        }
    }
}
